---
title: 'Alphabet Facade'
date: '2020-12-01'
location: 'Lisbon, Portugal'
coordinates: [38.7223, -9.1393]
description: 'A print archive''s blank street wall rebuilt as a ceramic alphabet — 5,000 azulejo tiles carrying a single letterform study, legible as text from nowhere and as typography from everywhere'
type: 'art'
tags: ['bauhaus', 'art', 'typography', 'ceramics']
authors:
  - name: 'Jonas Ferro'
    role: 'Artist'
  - name: 'Clara Voss'
    role: 'Letterform Consultant'
featured: false
---

## A wall that studies one letter

The print archive's north wall ran sixty metres without a window — the largest blank page in the neighbourhood. It now carries a single letterform study, tiled: the letter R, drawn 340 ways across five thousand azulejos, from strict compass-and-rule constructions to the loosest brush cursive, ordered so the wall drifts from geometry to gesture as the street slopes downhill.

Lisbon's facades have spoken in tile for three centuries; the piece only changes the subject. Each azulejo was silkscreened in cobalt on cream at a workshop across the river, using the archive's own specimen books as source — three of the 340 forms are traced from pages printed before the wall's own building existed.

## Reading distance

From across the avenue the wall is texture, a woven blue-grey. At the bus stop it resolves into alphabet. With your nose at the grout you find the tilemakers' registration marks, left visible by agreement — the piece is about how letters are made, and so is honest about how tiles are. Schoolchildren are sent to find the one R that is printed upside down. There are two.
