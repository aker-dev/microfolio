---
title: 'Mountain Studio for a Painter'
date: '2022-02-11'
location: 'Aspen, United States'
coordinates: [39.1911, -106.8175]
description: 'A painting studio at 2,600 metres for an artist who works large: one north rooflight the size of the floor, and a winch door that turns the gable into an easel'
type: 'architecture'
tags: ['bauhaus', 'architecture', 'studio', 'timber']
authors:
  - name: 'Marta Duran'
    role: 'Project Architect'
  - name: 'Kenji Morita'
    role: 'Consulting Architect'
featured: true
---

## North light, thin air

Aspen owes its modern shape to a Bauhaus émigré who spent three decades designing the town's posters, ski lodges and earthworks. The studio sits on a spruce-edged clearing above the town, and its brief was one sentence: north light for canvases up to five metres.

The answer is a timber shed whose entire roof plane is the window. A north-sloping rooflight, triple glazed against the altitude, washes the workwall with shadowless light from nine to five regardless of what the sky is doing. The stove, the sink and the daybed crowd the south wall under the low eave, leaving the tall side of the section entirely to work.

## The gable is a door

Five-metre canvases do not use doors politely. The east gable unlatches and winches outward into a horizontal canopy, opening a full-height slot through which paintings leave flat, crated and level. Twice a year, on delivery days, the studio effectively exhibits its own interior to the meadow.
