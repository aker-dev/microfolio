---
title: 'Brass Tea Service'
date: '2018-10-09'
location: 'Berlin, Germany'
coordinates: [52.5163, 13.3777]
description: 'A hand-raised tea service in brass and ebony — hemisphere, cylinder, disc — made in homage to the metal workshop that put geometry on the tea table a century ago'
type: 'design'
tags: ['bauhaus', 'design', 'metalwork', 'craft']
authors:
  - name: 'Lotte Brandt'
    role: 'Silversmith'
featured: false
---

## After the metal workshop

The famous 1924 tea infuser was barely eight centimetres tall and remains the heaviest small object in design history: a hemisphere on crossed runners, made by a workshop that believed geometry belonged in daily use, made by hand until industry caught up. This service is a hundred-year echo — raised by hand in Berlin, five pieces, no two runs identical.

The vocabulary is strict: hemispherical bodies, cylindrical handles wrapped in ebony, flat disc lids with a half-sphere for a knop. The teapot's spout is the one drawn curve in the set, and it took more attempts than everything else combined. Geometry is cheap in a sketch and expensive in brass.

## Use, not vitrine

A service this deliberate risks retirement into a display cabinet. The antidote is designed in: the brass is left unlacquered so daily handling polishes the high points and shadows the hollows, and the pot pours properly — tested through four hundred cups. Patina is the maintenance schedule. Each set is stamped with its firing date and nothing else.
