---
title: 'Circle, Triangle, Square — Poster Year'
date: '2019-03-15'
location: 'Vienna, Austria'
coordinates: [48.2082, 16.3738]
description: 'Fifty-two weekly posters for a concert hall, each built from the same three shapes and three colours — a year-long test of how much variety a closed system really holds'
type: 'design'
tags: ['bauhaus', 'design', 'poster', 'print']
authors:
  - name: 'Clara Voss'
    role: 'Graphic Designer'
featured: false
---

## A closed system, opened weekly

The 1923 questionnaire that matched circle to blue, triangle to yellow and square to red was bad science and excellent provocation. This commission took the provocation at its word: one year of concert posters, three shapes, three colours, and nothing else in the toolbox — no photography, no illustration, no second typeface.

Week by week, the constraint stopped feeling like a cage. A percussion night is forty small squares in a strict grid; a requiem is one blue circle sinking below the sheet edge; the new-music festival is the only poster where the triangle outnumbers everything. By June the shapes were vocabulary; by December they were slang.

## The archive as the artwork

Any single poster is modest. The wall of fifty-two is the actual piece — proof, pinned up in order, that a closed system generates rather than repeats. The concert hall now sells the complete year as a boxed set, and the questionnaire's answer sheet is reprinted on the lid, wrong as ever.
