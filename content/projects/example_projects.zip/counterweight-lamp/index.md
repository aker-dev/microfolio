---
title: 'Counterweight Table Lamp'
date: '2020-06-17'
location: 'Stuttgart, Germany'
coordinates: [48.7758, 9.1829]
description: 'A table lamp balanced by a sliding steel counterweight instead of springs or knobs: set the height with one finger, and the mechanism is the entire ornament'
type: 'design'
tags: ['bauhaus', 'design', 'product', 'lighting']
authors:
  - name: 'Atelier Primær'
    role: 'Product Design'
  - name: 'Lotte Brandt'
    role: 'Metalwork'
featured: false
---

## No springs, no knobs

Adjustable lamps mostly hide their physics — springs inside joints, friction inside knobs, all of it wearing out in private. This lamp does the opposite: a steel counterweight rides the stem in plain view, and where the weight sits is exactly where the shade floats. One finger raises the light; the mechanism is the explanation.

The stem is drawn steel tube, the foot a cast iron disc, the shade a spun aluminium hemisphere on a ball joint. Nothing is decorated and nothing is concealed, which after a hundred prototypes we can report is the more demanding of the two disciplines.

## Serviceable forever, or thereabouts

The lamp dismantles with one hex key into eleven parts, every one of them flat-stocked or catalogue-standard. The counterweight doubles as the packaging's ballast, the cardboard box converts into the shipping-damage test rig (drop it; the lamp should not care), and the care manual is one paragraph long. Warranty claims to date: a chewed cable. Dog.
