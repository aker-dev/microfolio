---
title: 'Tram Shelter System for Dessau'
date: '2022-09-08'
location: 'Dessau, Germany'
coordinates: [51.8367, 12.2455]
description: 'One steel module, four configurations, nineteen tram stops — a shelter family for the city that taught the world to build in series'
type: 'architecture'
tags: ['infrastructure', 'prefabrication', 'public-space']
authors:
  - name: 'Emil Kessler'
    role: 'Partner, Studio Vierkant'
  - name: 'Ruth Anders'
    role: 'Structural Engineer'
owner: 'Dessauer Verkehrsgesellschaft'
status: 'delivered'
surface_area: '19 × 14 m²'
cost: '840 000 €'
featured: false
---

## Serial production, seriously

Dessau is where industrial series stopped being a compromise and became a language. Designing street furniture here comes with homework. Our shelter is one folded steel portal, produced flat, galvanised, and bolted together on site in a morning.

### Four answers from one part

The same portal assembles into four configurations — single, double, corner and island — which between them cover all nineteen stops on the upgraded line. Roof, bench, timetable panel and lighting all hang off the same two rails, so the transit authority stocks exactly one spare of everything.

### What the pigeons taught us

The prototype spent a winter outside the depot. The revised roof pitch sheds snow onto the track side, the bench gained six degrees of backrest, and every horizontal surface above eye level is now sixty degrees from level. Design review by weather is slower than a crit, but harder to argue with.
