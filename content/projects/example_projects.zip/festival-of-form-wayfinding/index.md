---
title: 'Wayfinding for the Festival of Form'
date: '2024-08-19'
location: 'Dessau, Germany'
coordinates: [51.8397, 12.2473]
description: 'Signage for a ten-day design festival spread across a small city: 240 painted plywood signs, three shapes, three colours, and no arrows anywhere'
type: 'design'
tags: ['bauhaus', 'design', 'wayfinding', 'festival']
authors:
  - name: 'Clara Voss'
    role: 'Design Lead'
  - name: 'Taller Meridiano'
    role: 'Environmental Graphics'
featured: true
---

## Navigation without arrows

The festival's venues were scattered across a city most visitors had never walked. The conventional answer is arrows; the trouble with arrows is that they point somewhere for everyone, which in a city of corners means they mostly point wrong.

The system uses geometry instead. Each of the three festival routes owns a shape and a colour — red square, yellow circle, blue triangle — and the signs simply repeat the shape at every decision point, rotated to lean down the correct street. You follow a shape the way you follow a person: by keeping it in sight.

## Plywood, paint, weekend labour

All 240 signs were cut from standard plywood sheets in one workshop week and painted by volunteers on trestles in the Stadtpark. The paint scheme survived ten days of weather; the signs were auctioned afterward and now lean, apparently, in 240 hallways. The whole system cost less than the festival's coffee budget, a statistic we quote at every kickoff meeting since.
