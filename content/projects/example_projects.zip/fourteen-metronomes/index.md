---
title: 'Fourteen Metronomes'
date: '2026-03-13'
location: 'Prague, Czech Republic'
coordinates: [50.0755, 14.4378]
description: 'A gallery piece of fourteen mechanical metronomes on a resonant oak table, wound daily, drifting in and out of phase — order and entropy performing in shifts'
type: 'art'
tags: ['kinetic', 'sound']
authors:
  - name: 'Vera Lindqvist'
    role: 'Artist'
featured: false
---

## Wound at ten, chaos by noon

Every morning a gallery attendant winds fourteen mechanical metronomes, sets them all to 92 beats per minute, and starts them within a single sweep of the hand. For a few minutes they tick as one — a machine consensus. Then the tolerances speak: springs age differently, pivots wear differently, and by noon the room is a rainstorm of unsynchronised clicks.

And then, some afternoons, the table intervenes. The metronomes stand on one long oak slab, and through it each escapement nudges the others. Clusters lock into step for a minute, dissolve, reform elsewhere down the table. Physicists call it coupled oscillation; visitors call it the metronomes deciding.

## A daily performance without a performer

The piece has no motor, no sensor, no loop — only clockwork, wood and the day's slow argument between order and drift. Closing time is whenever the last metronome runs down, which the gallery has learned not to schedule. The attendants keep a log of the day's final ticker; after four months, one instrument leads by a margin no one can explain and no one will service away.
