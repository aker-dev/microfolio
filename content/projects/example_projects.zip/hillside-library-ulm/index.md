---
title: 'Hillside Library'
date: '2020-03-09'
location: 'Ulm, Germany'
coordinates: [48.3984, 9.9916]
description: 'A small public library terraced into the Kuhberg slope below the old design school, its reading rooms stepping downhill one shelf-height at a time'
type: 'architecture'
tags: ['concrete', 'landscape', 'public-space']
authors:
  - name: 'Emil Kessler'
    role: 'Partner, Studio Vierkant'
featured: false
---

## Downhill by shelf-heights

The site drops eleven metres from street to meadow. Rather than fight the slope with a big retaining move, the library steps down it in increments of exactly one bookshelf — 2.1 metres — so that section and furniture become the same drawing.

Each terrace is one reading room, one concrete tray, one long rooflight. The stair between terraces doubles as the browsing aisle, which means every route through the building passes every subject. Serendipity, load-bearing.

## An Ulm debt

The Hochschule für Gestaltung up the hill closed in 1968, but its habit of reducing a problem to its structure never left the city. The library's palette is the school's: raw concrete, black steel, beech. The librarians asked for one exception — a red children's room — and were right.
