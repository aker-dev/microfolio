---
title: 'Reading Pavilion on the Ilm'
date: '2024-04-12'
location: 'Weimar, Germany'
coordinates: [50.9755, 11.3312]
description: 'A timber pavilion in the Ilm park that lends books and shade in equal measure, a short walk from where the school that started everything held its first classes'
type: 'architecture'
tags: ['timber', 'public-space']
authors:
  - name: 'Emil Kessler'
    role: 'Partner, Studio Vierkant'
  - name: 'Marta Duran'
    role: 'Project Architect'
featured: true
---

## A shelf in the landscape

The brief asked for a summer reading room the city could unlock in April and forget about until October. We answered with a single gesture: one long shelf, folded three times, that becomes in turn a bench, a roof and a wall of books.

The pavilion sits on six screw piles and touches the park nowhere else. Every joint is dry — bolted larch, no glue, no concrete — so the building can leave the meadow as quietly as it arrived.

## Reading as a public act

Libraries indoors ask for silence. Outdoors, the contract loosens: children negotiate picture books, someone reads match reports aloud, a student sleeps under an open dictionary. The folded shelf shapes three rooms with three volumes of privacy, and the city's librarians restock it with a bicycle trailer.

- 1,400 books on loan, no card required
- 62 linear metres of shelf, of which 19 are bench
- zero fixings into the ground plane

The city asked us what happens when books get wet. They dry, mostly.
