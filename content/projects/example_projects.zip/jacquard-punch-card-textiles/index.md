---
title: 'Punch-Card Textiles'
date: '2023-04-27'
location: 'Zurich, Switzerland'
coordinates: [47.3769, 8.5417]
description: 'A weaving collection whose patterns are the punch cards that produce them — the loom instructions woven as the motif, on a restored 1912 Jacquard head'
type: 'design'
tags: ['bauhaus', 'design', 'textile', 'weaving']
authors:
  - name: 'Ines Vogel'
    role: 'Textile Designer'
  - name: 'Mira Halas'
    role: 'Loom Programmer'
featured: false
---

## The pattern is the program

A Jacquard loom reads punch cards; the cards are a picture of the cloth to come. This collection closes the loop: the motif woven into each textile is the card sequence that wove it, scaled so one punched hole becomes one square of the pattern. The cloth is its own source code, printed in the only language it has.

The weaving workshop tradition we lean on treated the loom as the era's most sophisticated machine and its discipline as composition, not decoration. Working on a restored 1912 Jacquard head makes the lineage literal: our design software's final output is a stack of cardboard cards, punched on the original perforator.

## Six cloths

The collection runs six pieces, from a cotton double-weave in cream and black to a wool rug where the card motif enlarges to architectural scale. Each is woven in an edition of twelve. The museum that houses the loom takes the first of every edition, along with the cards — filed, correctly, as both tooling and drawing.
