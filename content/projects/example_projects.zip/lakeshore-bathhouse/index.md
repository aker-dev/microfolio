---
title: 'Lakeshore Bathhouse'
date: '2021-07-16'
location: 'Chicago, United States'
coordinates: [41.9484, -87.6553]
description: 'A public bathhouse on the Lake Michigan shore: two black steel pavilions, one cold plunge, and a colonnade that frames the lake like a found painting'
type: 'architecture'
tags: ['public-space', 'steel']
authors:
  - name: 'Marta Duran'
    role: 'Project Architect'
  - name: 'Ruth Anders'
    role: 'Structural Engineer'
featured: true
---

## Less lake, more precisely

Chicago's shoreline has no shortage of lake. What it rations is the moment of transition — the threshold where a city person becomes a swimmer. The bathhouse is that threshold built at civic scale: changing rooms, showers, a sauna and a cold plunge, arranged as two pavilions holding a courtyard open to the water.

The steel frame is welded, painted black, and left to state its dimensions plainly. Between the pavilions runs a colonnade of eleven bays; each bay frames the horizon at a slightly different height, so walking its length tilts the lake like a slow hand on a picture rail.

## Winter is the season

The commission assumed a summer building. Attendance data argues otherwise: the sauna and plunge run October through April at capacity, and the courtyard's windbreak geometry came from a winter's worth of anemometer readings, not from the rendering. Cold water, it turns out, is a public amenity.
