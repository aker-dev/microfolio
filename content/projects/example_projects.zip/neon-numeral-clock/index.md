---
title: 'Station Clock with Neon Numerals'
date: '2024-01-18'
location: 'Brussels, Belgium'
coordinates: [50.8467, 4.3499]
description: 'A public clock for a tram terminus that abandons hands: the hour glows as a two-metre neon numeral, the minutes as a climbing edge of light around the frame'
type: 'design'
tags: ['public-space', 'lighting']
authors:
  - name: 'Atelier Primær'
    role: 'Product Design'
  - name: 'Vera Lindqvist'
    role: 'Light Consultant'
featured: false
---

## Time you can read across a square

A clock face with hands is an instrument for the person standing under it. A tram terminus needs the opposite: time legible at 200 metres through sleet, by someone deciding whether to run. The clock shows the hour as a single two-metre numeral bent in neon, and the minutes as a bar of light climbing the frame's edge — at quarter past, the frame is a quarter lit.

The numerals swap on the hour with a three-second crossfade that has become, unexpectedly, a small public event. On New Year's Eve the crowd counts it down.

## Neon, on purpose

LED could imitate the look at half the power, and the first study specified it. Full-scale mockups ended the debate: neon's continuous stroke reads as a drawn line where the LED segments read as a display. The tubes are bent by one of Belgium's last neon workshops, the transformers are serviceable from a hatch, and the whole sign draws less than the terminus's coffee machine. Craft won on legibility, and it photographs like a promise kept.
