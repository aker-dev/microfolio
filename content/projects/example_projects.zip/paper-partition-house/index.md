---
title: 'Paper Partition House'
date: '2023-01-30'
location: 'Tokyo, Japan'
coordinates: [35.6762, 139.6503]
description: 'A house for a family of five on a seven-metre lot, its rooms drawn and redrawn weekly by paper honeycomb partitions light enough for a child to move'
type: 'architecture'
tags: ['housing', 'flexibility']
authors:
  - name: 'Kenji Morita'
    role: 'Architect'
featured: false
---

## A plan that refuses to be final

The clients asked for four bedrooms on a lot where three would be generous. The house answers with one room, seven by eleven metres, two storeys tall at the street and one at the garden — and a set of nine paper honeycomb partitions, each 40 millimetres thick and light enough for the eight-year-old to relocate.

The partitions run on ceiling tracks laid out on a tatami-derived grid. Bedrooms exist at night; by ten the next morning the same floor area has usually become one long workroom. The family's floor plan is best described as a weekly average.

### Serviced edges, free middle

Everything that needs a pipe or a wire — kitchen, baths, stairs, storage — is pressed into a thick wall along the north lot line. The middle of the house owns nothing and can therefore become anything. Furniture is the only permanent architecture: one ten-metre table, built where the room was widest, around which the partitions now negotiate.
