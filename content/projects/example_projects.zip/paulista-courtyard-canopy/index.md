---
title: 'Courtyard Canopy off Avenida Paulista'
date: '2024-10-03'
location: 'São Paulo, Brazil'
coordinates: [-23.5614, -46.6559]
description: 'A concrete canopy over a mid-block courtyard, thick enough to carry a garden, thin enough at its edge to read as a drawn line against the towers'
type: 'architecture'
tags: ['bauhaus', 'architecture', 'concrete', 'public-space']
authors:
  - name: 'Salim Bouzid'
    role: 'Site Architect'
  - name: 'Ruth Anders'
    role: 'Structural Engineer'
owner: 'Instituto Paulista de Arte Moderna'
status: 'delivered'
surface_area: '380 m²'
cost: 'R$ 4 200 000'
featured: false
---

## Shade is infrastructure

São Paulo's modernists understood that in this climate the primary public building is a roof. The institute's courtyard — a leftover between three lot lines — needed to work as lobby, stage and refuge, which is to say it needed shade with conviction.

The canopy is a single concrete plate on four columns, 45 centimetres deep at the columns and 9 at the free edge. The depth it keeps is honest: the plate carries half a metre of soil and a garden of philodendrons whose roots do the cooling the air conditioning no longer has to.

## Under it

Programming under the canopy is deliberately loose. Wednesday is the book market, Friday evenings are film screenings against the blank neighbouring wall, and the rest of the week it is the neighbourhood's best waiting room. The institute counts users with a clicker at the gate: two thousand on a quiet week.
