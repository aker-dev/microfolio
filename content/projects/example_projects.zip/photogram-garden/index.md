---
title: 'Photogram Garden'
date: '2021-09-02'
location: 'Montpellier, France'
coordinates: [43.6119, 3.8772]
description: 'An outdoor installation of two hundred cyanotype panels exposed in place through a summer in France’s oldest botanical garden, recording the shadows of the garden that surrounds them'
type: 'art'
tags: ['bauhaus', 'art', 'photography', 'landscape']
authors:
  - name: 'Theo Marchand'
    role: 'Artist'
  - name: 'Ines Vogel'
    role: 'Fabrication'
featured: false
---

## Photography without a camera, weather permitting

A photogram is the oldest photographic act: lay an object on sensitised paper, let light do the drawing. The garden version scales the act to a park. Two hundred cyanotype-coated aluminium panels were installed among the beds in June — under fennel, beneath the lime tree, along the pond edge — and left exposed until September.

Each panel is a long-exposure portrait of its own location: the hard shadow of an iron railing crossed by three months of swaying grasses, gusts recorded as blur, still afternoons as edges. The prussian blue develops in place, fixed by the first autumn rain the way the process was fixed in a darkroom sink.

## The archive of one summer

Re-hung in a grid for the winter exhibition, the panels become a map of the garden drawn by the garden. Botanists identified forty species from silhouette alone; one visitor located the exact bench she read on in July by the shadow of her bicycle. The panels will not be re-coated — the piece is that summer, in an edition of one.
