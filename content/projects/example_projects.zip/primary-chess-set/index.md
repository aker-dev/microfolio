---
title: 'Primary Chess Set'
date: '2021-12-06'
location: 'Weimar, Germany'
coordinates: [50.9795, 11.3235]
description: 'A chess set in which every piece is the diagram of its own move — turned beech, three colours, and a hundred-year-old argument continued in the same workshop town'
type: 'design'
tags: ['bauhaus', 'design', 'product', 'wood']
authors:
  - name: 'Atelier Primær'
    role: 'Product Design'
featured: true
---

## Form follows move

The 1924 original replaced kings and knights with geometry: each piece shaped by how it moves. Our set keeps the thesis and re-derives every form from scratch, on the grounds that an argument this good deserves to be had twice.

The bishop is a diagonal wedge, the rook a plain cube, the knight an L of two glued blocks, the queen a sphere on a cylinder — omnidirectional, dominant. The pawn is the smallest turnable cylinder that still feels like a decision when you push it. Beech throughout; the third colour marks the four centre squares, the only squares the rules themselves privilege.

## Learning chess by looking

1. Set the board with the pieces facing a beginner.
2. Explain nothing.
3. Time how long before they infer the bishop.

Median across our test group of forty: under three minutes. The set ships flat in a birch box whose lid is the board, and the box lid's grid is silkscreened fractionally off-centre — our one concession to the fact that perfect symmetry photographs worse than it plays.
