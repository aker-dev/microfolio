---
title: 'Primary Colours for a Grey Underpass'
date: '2025-05-30'
location: 'Budapest, Hungary'
coordinates: [47.4979, 19.0402]
description: 'A 120-metre pedestrian underpass repainted as a walkable colour theory lesson: red compressing, yellow accelerating, blue arriving — maintenance schedule included'
type: 'art'
tags: ['bauhaus', 'art', 'public-space', 'colour']
authors:
  - name: 'Mira Halas'
    role: 'Artist'
  - name: 'Taller Meridiano'
    role: 'Environmental Graphics'
owner: 'Budapest Közút'
status: 'delivered'
surface_area: '1 450 m²'
cost: '38 000 000 Ft'
featured: true
---

## A corridor as a colour course

The underpass under the ring road moved eleven thousand people a day through 120 metres of sodium-lit grey. The commission asked for "art"; the site asked for colour theory. The walk is now a sequence: a red zone that visually compresses the wide entry hall, a long yellow run whose diagonal stripes accelerate the monotonous middle, and a blue vault at the far stair that reads as arrival — depth, calm, sky.

The theory is old classroom material: colours advance and recede, warm hurries, cool settles. What the classroom never had is a control group of eleven thousand commuters. Pedestrian counts show fewer stalls at the entry pinch; the transit authority's surveys stopped listing the underpass among "avoided at night" locations within a season.

## Paint is a schedule

Public colour fails by fading, not by vandalism. The palette is specified in mineral silicate paint with published repaint intervals, the city crew got a colour book with mixing codes, and the budget line everyone fought for was not the mural — it was the maintenance contract. Colour that stays is the artwork; colour that fades is a complaint.
