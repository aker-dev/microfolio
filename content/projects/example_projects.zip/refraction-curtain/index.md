---
title: 'Refraction Curtain'
date: '2019-08-21'
location: 'New York, United States'
coordinates: [40.7614, -73.9776]
description: 'A lobby-scale curtain of 3,000 cast glass prisms that takes one office atrium''s worth of daylight and spends it as moving spectra on the floor'
type: 'art'
tags: ['bauhaus', 'art', 'glass', 'light']
authors:
  - name: 'Theo Marchand'
    role: 'Artist'
featured: false
---

## Spending daylight

The glass workshop of the old school treated coloured light as material, cutting and layering it like joinery. The curtain works the same trade with clear glass only: three thousand cast prisms, each the size of a matchbox, hung on stainless cable across a forty-foot atrium wall. Colour is not applied; it is extracted — the prisms unpack the lobby's south light into spectra that travel the terrazzo floor as the sun moves.

The piece keeps office hours. Winter mornings throw long violet bands past the security desk; June noon pools the colour tight against the wall. Overcast days are the piece's rest state: a grey shimmer, glass being honest about the weather.

## Three thousand, not one

A single prism is a physics demonstration. The multiplication is what makes weather indoors — no two prisms aligned identically, so the spectra arrive layered, interfering, slightly wrong in the way water reflections are slightly wrong. Casting tolerances were loosened, not tightened, after the first mockup: precision made it look like a chandelier. Error made it look like light.
