---
title: 'Shophouse Rooftop Studios'
date: '2023-06-21'
location: 'Bangkok, Thailand'
coordinates: [13.7563, 100.5018]
description: 'Eleven artist studios landed on the flat roofs of a row of Charoen Krung shophouses, visible from the street only as a rhythm of deep-eaved sawteeth'
type: 'architecture'
tags: ['bauhaus', 'architecture', 'adaptive-reuse', 'rooftop']
authors:
  - name: 'Kenji Morita'
    role: 'Architect'
  - name: 'Marta Duran'
    role: 'Consulting Architect, Studio Vierkant'
owner: 'Charoen Krung Arts Cooperative'
status: 'delivered'
surface_area: '640 m²'
cost: '18 000 000 ฿'
featured: true
---

## Building over the shophouses

Bangkok's old commercial streets are rows of shophouses — narrow, deep, and crowned by flat roofs the city has never had a plan for. Along Charoen Krung, the oldest paved road in town, a cooperative of eleven artists bought the air rights over one row and asked for studios.

The studios are steel-framed sawteeth with eaves pulled deep over their glazing, set back from the parapet by the width of a laundry line. In this climate the section works twice: the high side exhausts hot air through operable louvres, the low side drinks indirect light without the heat. From the street you see a serration against the sky — a second horizon rather than a second building.

## Eleven rooms, one contract

The cooperative leases the studios at cost to working artists for five-year terms. In return, the ground-floor shopfronts host two open-studio weekends a year. The shophouses got new cores, new waterproofing and a shaded roofscape out of the deal; the artists got rooms that stay workable through the hot season without a compressor in sight.

---

The district authority asked for reversibility. Every studio can be unbolted and craned off in a day, leaving four pad footings and a better roof than we found.
