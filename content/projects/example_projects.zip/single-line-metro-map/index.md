---
title: 'The Metro as a Single Line'
date: '2022-11-22'
location: 'Mexico City, Mexico'
coordinates: [19.4326, -99.1332]
description: 'A commissioned study redrawing a twelve-line metro network as one continuous line that never crosses itself — useless for engineers, unreasonably good at teaching the city its own shape'
type: 'design'
tags: ['cartography', 'identity']
authors:
  - name: 'Taller Meridiano'
    role: 'Design Studio'
featured: true
---

## An impossible brief, kept

The transit authority asked for a poster celebrating fifty years of the metro. We countered with a constraint instead of a concept: redraw all twelve lines as one unbroken line that visits every station once and never crosses itself. If the network is really one system, let it be drawn as one gesture.

Topology had opinions. Making the line work meant bending the city — the east side compresses, the airport swings north, and two transfer stations trade places. Every distortion is documented in the margin like a chess annotation, because a map that lies should at least keep honest books.

## What a wrong map is for

Riders do not navigate with it; that is what the real map is for. What the single line does is give the network a silhouette — an outline people recognise the way they recognise the city's skyline. The poster hangs in 195 stations, the line animates as the system's loading indicator, and schoolchildren trace it in one pencil stroke, which is the entire thesis stated in a classroom.
