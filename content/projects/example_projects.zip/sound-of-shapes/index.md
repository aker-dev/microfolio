---
title: 'The Sound of Shapes'
date: '2024-05-07'
location: 'Montreal, Canada'
coordinates: [45.5019, -73.5674]
description: 'An audiovisual room where drawing is scoring: visitors draw circles, triangles and squares on a shared surface and hear the wall orchestra play their composition'
type: 'art'
tags: ['interactive', 'sound']
authors:
  - name: 'Theo Marchand'
    role: 'Artist'
  - name: 'Mira Halas'
    role: 'Sound Design'
featured: false
---

## Synesthesia, playable

A century of art theory has insisted that shapes sound: the circle hums, the triangle strikes, the square keeps time. The room stops insisting and lets people check. A shared drawing surface faces a wall of forty small speakers; whatever is drawn becomes a score, read left to right on a loop, shapes voiced by position and size.

Circles are sine tones, warm and long. Triangles attack — struck metal, decay by altitude. Squares are rhythm, subdividing the loop. A page of careful geometry plays as chamber music; a child's scribble plays as exactly what it is. Erasing is composing too, and the eraser is oversized on purpose.

## What the room learned

Twenty minutes is the median stay, absurd for a one-room piece. Strangers collaborate without negotiating — someone lays a square tempo, someone else floats circles over it, and the room fills with an authorless composition every evening at closing. The installation logs nothing and keeps no recordings: the scores exist only while drawn, which visitors, told this, invariably draw one more.
