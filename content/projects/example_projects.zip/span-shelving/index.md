---
title: 'Span Shelving System'
date: '2021-05-04'
location: 'Copenhagen, Denmark'
coordinates: [55.6761, 12.5683]
description: 'A shelving system with no uprights: anodised aluminium shelves that clamp directly to any two walls, turning the room itself into the structure'
type: 'design'
tags: ['furniture', 'aluminium']
authors:
  - name: 'Atelier Primær'
    role: 'Product Design'
featured: false
---

## Furniture minus half of itself

Every shelving system reinvents the same redundancy: a frame, standing in front of a wall, which is already a frame. Span deletes the redundancy. The shelf is a folded aluminium extrusion with a clamping jaw at each end; it grips opposing walls — corridor, alcove, window reveal — and carries books on the strength of the room.

The engineering lives in the jaw: a cam lever presses a gasketed pad against each wall with 4 kN of force, no drilling, no fixings, no trace at removal. Rated span is 2.4 metres at 60 kilograms; the test rig held a colleague.

## Rooms it turns out we had

Span's real discovery was architectural. Corridors, stair landings, the dead zone over a radiator — every dwelling holds shelf-shaped rooms that freestanding furniture cannot reach. The system ships as single shelves in four lengths and three colours (cream, black, signal red), and the installation manual is printed on the packing sleeve in eleven drawings and zero words.
