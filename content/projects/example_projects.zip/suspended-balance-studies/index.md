---
title: 'Suspended Balance Studies'
date: '2023-09-12'
location: 'Rotterdam, Netherlands'
coordinates: [51.9225, 4.4792]
description: 'Nine hanging constructions of steel rod, painted discs and counterweights, holding their equilibrium in a former turbine hall and redrawing it with every draught'
type: 'art'
tags: ['bauhaus', 'art', 'kinetic', 'sculpture']
authors:
  - name: 'Vera Lindqvist'
    role: 'Artist'
featured: true
---

## Equilibrium as a subject

The preliminary course a century ago set students a deceptively simple exercise: build a construction that holds its balance, and show how. These nine pieces take the exercise at gallery scale. Each is a hanging system of steel rod, painted aluminium discs and lead counterweights, trimmed until it floats level — then left alone to answer the room.

The turbine hall's air is never still. Doors, bodies, the afternoon sun on the west glazing: every disturbance travels the wires and settles into a new attitude, always balanced, never twice the same. The work is not the object but the recovery.

## Tuning, not sculpting

Studio time was spent less like a sculptor's and more like a piano tuner's: shortening a rod by four millimetres, adding a five-gram washer, listening with a spirit level. The install took nine days, eight of which were trimming. Visitors are permitted — encouraged, by a sign the guards have learned to tolerate — to breathe on the smallest piece.
