---
title: 'Törten Community Hall'
date: '2019-11-05'
location: 'Dessau-Törten, Germany'
coordinates: [51.813, 12.231]
description: 'A brick hall for the 1928 Törten estate that borrows its neighbours: their module, their window rhythm, and their conviction that ordinary life deserves composed space'
type: 'architecture'
tags: ['bauhaus', 'architecture', 'brick', 'community']
authors:
  - name: 'Emil Kessler'
    role: 'Partner, Studio Vierkant'
  - name: 'Ruth Anders'
    role: 'Structural Engineer'
featured: false
---

## A hall the estate never got

The Törten estate was built as a housing experiment with everything a household needs — except anywhere for three hundred households to meet. Ninety years later the residents' association bought the corner plot the plan had always left blank.

The hall is one room, ten metres by twenty, in load-bearing brick laid to the same 1.25-metre module as the houses around it. The roof is a folded concrete plate that lets the room span without columns; its folds carry the acoustic absorption, so the ceiling does the work the walls are too honest to hide.

## Programme by committee, happily

The association runs the calendar, and the calendar runs the building: gymnastics before school, a repair café on Saturdays, table tennis in winter, and weddings whenever. The kitchen hatch and the storage wall came directly from two years of residents' meetings. The colour scheme — three doors, three primaries — was the only decision nobody disputed.
