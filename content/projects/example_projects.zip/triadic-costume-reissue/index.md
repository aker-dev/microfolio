---
title: 'Triadic Costumes, Reissued'
date: '2022-06-08'
location: 'Stuttgart, Germany'
coordinates: [48.7784, 9.18]
description: 'Six costumes from the 1922 Triadic Ballet rebuilt with a dance company for performing bodies, in materials that can survive a touring season'
type: 'art'
tags: ['performance', 'costume']
authors:
  - name: 'Vera Lindqvist'
    role: 'Artist'
  - name: 'Ines Vogel'
    role: 'Costume Fabrication'
featured: true
---

## Dancing the diagram

The Triadic Ballet turned dancers into geometry a century ago: spiral wire skirts, sphere hands, a costume history has filed somewhere between sculpture and prank. Museum replicas exist, built to stand in vitrines. This reissue was built to sweat — six costumes remade with a Stuttgart company for an evening-length revival, then a touring season.

Every form was re-engineered from the body outward. The spiral skirt is now aircraft-grade aluminium tube on a padded harness, the spheres are vacuum-formed and split for airflow, and each costume packs into one flight case. Weight came down by two-thirds; the silhouette conceded nothing visible past the third row.

## What the constraint choreographs

Rehearsals confirmed the old suspicion that the costumes are the choreographer. A dancer in a sphere-skirt cannot improvise past its radius; the costume's geometry writes the movement vocabulary, which is the piece's whole argument about bodies and form. The company's notation now includes a column the 1922 originals implied but never wrote down: what the costume permits.
