---
title: 'Garden Room for a Glass Villa'
date: '2018-05-24'
location: 'Brno, Czech Republic'
coordinates: [49.2074, 16.6161]
description: 'An orangery at the foot of a functionalist villa garden, built as a conversation with the house above: the same travertine floor, the opposite attitude to glass'
type: 'architecture'
tags: ['bauhaus', 'architecture', 'glass', 'heritage']
authors:
  - name: 'Ayala Ron'
    role: 'Architect'
featured: false
---

## Answering a masterpiece quietly

The villa on the hill is one of the sacred rooms of modern architecture, and its garden falls away in terraces the tour groups never reach. At the bottom terrace the foundation wanted a winter garden — somewhere to overwinter the citrus and hold small lectures without ticketing the house itself.

The room takes the villa's travertine floor and continues it, then inverts every other rule: where the house dissolves its corners with plate glass, the garden room is a solid masonry box with one enormous south window that pivots open like an instrument case. In summer the room is effectively a porch; in January it is a bright, humid, leaf-scented refuge two degrees above frost.

Lectures happen among the lemon trees, forty chairs maximum. The gardeners hold veto power over the calendar, which everyone agrees is the correct hierarchy.
