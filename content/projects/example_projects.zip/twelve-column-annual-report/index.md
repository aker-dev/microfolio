---
title: 'Annual Report on Twelve Columns'
date: '2020-09-25'
location: 'Basel, Switzerland'
coordinates: [47.5596, 7.5886]
description: 'A cultural foundation''s annual report set on a strict twelve-column grid that carries text, tables and finances alike — typography doing the work of illustration'
type: 'design'
tags: ['bauhaus', 'design', 'editorial', 'typography']
authors:
  - name: 'Clara Voss'
    role: 'Graphic Designer'
  - name: 'Ines Vogel'
    role: 'Production'
featured: false
---

## One grid for prose and money

Annual reports usually run two designs in one cover: an illustrated front half and a financial back half nobody styles. This report refuses the split. A twelve-column grid carries everything — essays on six columns, captions on two, and the accounts on column settings chosen so that a balance sheet and a photo caption are visibly citizens of the same page.

The typographic palette is one family in three optical sizes, black on unbleached stock, with the foundation's red reserved for one job only: totals. Restraint is easy to declare and hard to invoice, so the grid documentation became part of the deliverable — the foundation's future designers inherit the reasoning, not just the artefact.

### The columns, by the numbers

| Element        | Columns | Note                       |
| -------------- | ------- | -------------------------- |
| Essays         | 6       | ragged right               |
| Interviews     | 4 + 2   | questions in the margin    |
| Balance sheet  | 9       | tabular figures            |
| Notes & colophon | 3     | smallest optical size      |

The auditors asked why the accounts looked better than the essays. Correct question, wrong direction: the essays looked, at last, as ordered as the accounts.
