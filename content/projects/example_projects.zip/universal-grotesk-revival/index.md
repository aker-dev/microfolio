---
title: 'Universal Grotesk Revival'
date: '2025-09-01'
location: 'Berlin, Germany'
coordinates: [52.52, 13.405]
description: 'A four-year revival of a 1920s single-case experimental alphabet, extended from 26 surviving letterforms to a working family of 14 styles with full European language support'
type: 'design'
tags: ['bauhaus', 'design', 'typography', 'revival']
authors:
  - name: 'Clara Voss'
    role: 'Type Designer'
  - name: 'Lotte Brandt'
    role: 'Research'
featured: true
---

## One case, one century later

In 1925 an experimental alphabet argued that two alphabets — capital and small — were one too many. The surviving drawings total twenty-six letterforms, four digits and a question mark. This revival takes the argument seriously enough to finish it.

The geometry looks compass-drawn and is not: the original circles were corrected by eye everywhere the eye demanded it, and the revival's first year went into learning which corrections were principle and which were 1925. Optical compensation is the tradition being revived, not the grid.

## From artefact to instrument

A working family needs what the drawings never had: weights, a text cut with taller proportions, currency symbols, diacritics for forty languages, and the unglamorous kerning of quotation marks. The family now runs from Hair to Poster in fourteen styles.

- 1,120 glyphs per style
- Latin extended, Greek, and Cyrillic
- variable axes for weight and optical size

The specimen site sets the whole of a 1929 lecture on typography in the single case the lecture called for. The argument reads better than it did in 1925 — which is what a revival is for.
