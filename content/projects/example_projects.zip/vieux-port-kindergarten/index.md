---
title: 'Rooftop Kindergarten above the Vieux-Port'
date: '2025-02-14'
location: 'Marseille, France'
coordinates: [43.2951, 5.374]
description: 'A kindergarten on the roof of a 1950s cooperative block: a shaded playground at parapet level, four classrooms under sawtooth vaults, and the harbour as a teaching aid'
type: 'architecture'
tags: ['education', 'rooftop']
authors:
  - name: 'Marta Duran'
    role: 'Project Architect'
  - name: 'Salim Bouzid'
    role: 'Site Architect'
owner: 'Ville de Marseille'
status: 'ongoing'
surface_area: '520 m²'
cost: '1 750 000 €'
featured: false
---

## The roof as a commons

The modernists promised roofs that would earn their keep — gymnasiums, running tracks, kindergartens in the sky. Most of those promises stayed on paper. This one is being built: four classrooms and a shaded court on the roof of a housing cooperative a street back from the Vieux-Port.

The classrooms sit under shallow concrete sawtooths that scoop north light and shrug off the mistral. The court is planted with three pines in oversized terracotta pots, because a playground at parapet height needs shade it can move.

### Working over ninety households

Building on an occupied roof is a logistics project wearing an architecture project's clothes. Every element arrives by crane on Tuesday mornings, the only slot the co-op voted for. The concrete is precast, the facade is bolted aluminium, and the loudest week of the programme — cutting the new stair through — was scheduled for the school holidays. Handover is set for the autumn term.
